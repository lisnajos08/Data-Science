list = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]
print(type(list))
print(list)
tuple = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat")
print(type(tuple))
print(tuple)
set = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"}
print(type(set))
print(set)
dict = {
    "d1" : "Sun",
    "d2" : "Mon",
    "d3" : "Tue",
    "d4" : "Wed",
    "d5" : "Thu",
    "d6" : "Fri",
    "d7" : "Sat"
}
print(type(dict))
print(dict)